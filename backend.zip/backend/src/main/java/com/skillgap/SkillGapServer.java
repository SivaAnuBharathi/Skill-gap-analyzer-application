package com.skillgap;

import com.sun.net.httpserver.HttpServer;
import com.sun.net.httpserver.HttpHandler;
import com.sun.net.httpserver.HttpExchange;
import java.io.*;
import java.net.InetSocketAddress;
import java.nio.charset.StandardCharsets;
import java.util.*;

/**
 * Main HTTP Server for the Skill Gap Analyser application.
 * Uses Java's built-in HttpServer (no external dependencies required).
 * Serves the frontend files and provides REST API endpoints.
 */
public class SkillGapServer {

    private static final int PORT = 8080;

    public static void main(String[] args) throws IOException {
        int port = args.length > 0 ? Integer.parseInt(args[0]) : PORT;
        HttpServer server = HttpServer.create(new InetSocketAddress(port), 0);

        // API endpoint for skill gap analysis
        server.createContext("/api/analyze", new AnalyzeHandler());

        // API endpoint for available job roles
        server.createContext("/api/jobs", new JobsHandler());

        // Serve static frontend files
        server.createContext("/", new StaticFileHandler());

        server.setExecutor(null);
        server.start();
        System.out.println("==============================================");
        System.out.println("  Skill Gap Analyser Server Started!");
        System.out.println("  Open http://localhost:" + port + " in your browser");
        System.out.println("==============================================");
    }

    /**
     * Handles POST /api/analyze
     * Receives user data and returns skill gap analysis.
     */
    static class AnalyzeHandler implements HttpHandler {
        @Override
        public void handle(HttpExchange exchange) throws IOException {
            // Set CORS headers
            exchange.getResponseHeaders().set("Access-Control-Allow-Origin", "*");
            exchange.getResponseHeaders().set("Access-Control-Allow-Methods", "POST, OPTIONS");
            exchange.getResponseHeaders().set("Access-Control-Allow-Headers", "Content-Type");

            if ("OPTIONS".equalsIgnoreCase(exchange.getRequestMethod())) {
                exchange.sendResponseHeaders(204, -1);
                return;
            }

            if (!"POST".equalsIgnoreCase(exchange.getRequestMethod())) {
                String error = "{\"error\": \"Method not allowed\"}";
                exchange.getResponseHeaders().set("Content-Type", "application/json");
                byte[] bytes = error.getBytes(StandardCharsets.UTF_8);
                exchange.sendResponseHeaders(405, bytes.length);
                exchange.getResponseBody().write(bytes);
                exchange.getResponseBody().close();
                return;
            }

            // Read request body
            InputStream is = exchange.getRequestBody();
            String body = new String(is.readAllBytes(), StandardCharsets.UTF_8);

            // Parse JSON manually (no external libraries)
            String name = extractJsonValue(body, "name");
            String age = extractJsonValue(body, "age");
            String education = extractJsonValue(body, "education");
            String desiredJob = extractJsonValue(body, "desiredJob");
            String currentSkills = extractJsonValue(body, "currentSkills");

            // Perform skill gap analysis
            String response = SkillGapAnalyzer.analyze(name, age, education, desiredJob, currentSkills);

            exchange.getResponseHeaders().set("Content-Type", "application/json");
            byte[] responseBytes = response.getBytes(StandardCharsets.UTF_8);
            exchange.sendResponseHeaders(200, responseBytes.length);
            OutputStream os = exchange.getResponseBody();
            os.write(responseBytes);
            os.close();
        }
    }

    /**
     * Handles GET /api/jobs
     * Returns available job roles for the dropdown.
     */
    static class JobsHandler implements HttpHandler {
        @Override
        public void handle(HttpExchange exchange) throws IOException {
            exchange.getResponseHeaders().set("Access-Control-Allow-Origin", "*");
            exchange.getResponseHeaders().set("Content-Type", "application/json");

            String response = SkillGapAnalyzer.getJobRolesJson();
            byte[] responseBytes = response.getBytes(StandardCharsets.UTF_8);
            exchange.sendResponseHeaders(200, responseBytes.length);
            OutputStream os = exchange.getResponseBody();
            os.write(responseBytes);
            os.close();
        }
    }

    /**
     * Serves static files from the frontend directory.
     */
    static class StaticFileHandler implements HttpHandler {
        @Override
        public void handle(HttpExchange exchange) throws IOException {
            String path = exchange.getRequestURI().getPath();
            if (path.equals("/")) {
                path = "/index.html";
            }

            // Resolve the file from the frontend directory
            String basePath = System.getProperty("user.dir");
            File file = new File(basePath + File.separator + "frontend" + path.replace("/", File.separator));

            if (!file.exists() || file.isDirectory()) {
                String notFound = "<h1>404 - Not Found</h1>";
                exchange.sendResponseHeaders(404, notFound.length());
                exchange.getResponseBody().write(notFound.getBytes());
                exchange.getResponseBody().close();
                return;
            }

            // Determine content type
            String contentType = getContentType(path);
            exchange.getResponseHeaders().set("Content-Type", contentType);

            byte[] fileBytes = java.nio.file.Files.readAllBytes(file.toPath());
            exchange.sendResponseHeaders(200, fileBytes.length);
            OutputStream os = exchange.getResponseBody();
            os.write(fileBytes);
            os.close();
        }

        private String getContentType(String path) {
            if (path.endsWith(".html")) return "text/html; charset=UTF-8";
            if (path.endsWith(".css")) return "text/css; charset=UTF-8";
            if (path.endsWith(".js")) return "application/javascript; charset=UTF-8";
            if (path.endsWith(".json")) return "application/json";
            if (path.endsWith(".png")) return "image/png";
            if (path.endsWith(".jpg") || path.endsWith(".jpeg")) return "image/jpeg";
            if (path.endsWith(".svg")) return "image/svg+xml";
            if (path.endsWith(".ico")) return "image/x-icon";
            return "application/octet-stream";
        }
    }

    /**
     * Simple JSON value extractor (no external library needed).
     */
    static String extractJsonValue(String json, String key) {
        String searchKey = "\"" + key + "\"";
        int keyIndex = json.indexOf(searchKey);
        if (keyIndex == -1) return "";

        int colonIndex = json.indexOf(":", keyIndex + searchKey.length());
        if (colonIndex == -1) return "";

        // Skip whitespace
        int valueStart = colonIndex + 1;
        while (valueStart < json.length() && json.charAt(valueStart) == ' ') {
            valueStart++;
        }

        if (valueStart >= json.length()) return "";

        if (json.charAt(valueStart) == '"') {
            // String value
            int valueEnd = json.indexOf("\"", valueStart + 1);
            if (valueEnd == -1) return "";
            return json.substring(valueStart + 1, valueEnd);
        } else {
            // Number or other value
            int valueEnd = valueStart;
            while (valueEnd < json.length() && json.charAt(valueEnd) != ',' && json.charAt(valueEnd) != '}') {
                valueEnd++;
            }
            return json.substring(valueStart, valueEnd).trim();
        }
    }
}
